import logging
import os
import uuid
import json
import shutil
from datetime import datetime, timedelta
from collections import defaultdict
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Updater,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    Filters,
    CallbackContext,
)
import urllib3.exceptions
import requests
import qrcode
import html

# Logging setup
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# In-memory storage
users = {}  # {user_id: {"username": str, "name": str, "balance": float, "purchases": list, "gifts": int}}
configs = {}  # {config_id: {"name": str, "price": float, "filename": str, "original_filename": str, "description": dict}}
purchase_logs = []
access_logs = []
gift_codes = {}  # {code: {"value": float, "used": bool, "user_id": int or None}}
user_locks = {}  # {user_id: datetime} for rate limiting
request_counts = defaultdict(list)  # {user_id: [timestamps]} for abuse detection
banned_users = set()  # {user_id}
bot_locked = False  # Bot maintenance lock
group_membership_cache = {}  # {user_id: (timestamp, is_member)}
OWNER_ID = 8023190887
GROUP_LOG_ID = -1002582227269
GROUP_REQUIRED_ID = -1002666746441  # REPLACE WITH ACTUAL @ConfigBrasil ID
CONFIG_DIR = "configs"
DATA_FILE = "users_data.json"
BACKUP_DATA_FILE = "backup_users_data.json"
ALLOWED_EXTENSIONS = {'.loli', '.txt', '.config', '.svb'}

# Ensure config directory exists
if not os.path.exists(CONFIG_DIR):
    os.makedirs(CONFIG_DIR)

def sanitize_html(text: str) -> str:
    """Sanitize HTML by escaping invalid tags and replacing <br> with \n."""
    text = text.replace('<br>', '\n')
    text = html.escape(text, quote=False)
    valid_tags = ['b', 'i', 'u', 's', 'code', 'pre', 'a']
    for tag in valid_tags:
        text = text.replace(f'&lt;{tag}&gt;', f'<{tag}>').replace(f'&lt;/{tag}&gt;', f'</{tag}>')
    text = text.replace('&quot;', '"').replace('&amp;', '&')
    return text

def save_users_data():
    """Save users, configs, logs, and gift codes to JSON with backup."""
    try:
        if os.path.exists(DATA_FILE):
            shutil.copy(DATA_FILE, BACKUP_DATA_FILE)
        data = {
            "users": users,
            "configs": configs,
            "purchase_logs": [
                {k: v if k != "timestamp" else v.isoformat() for k, v in log.items()}
                for log in purchase_logs
            ],
            "access_logs": access_logs,
            "gift_codes": gift_codes,
            "banned_users": list(banned_users),
        }
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save users data: {e}")
        send_log(None, f"Erro ao salvar dados: {e}")

def load_users_data():
    """Load users, configs, logs, and gift codes from JSON."""
    global users, configs, purchase_logs, access_logs, gift_codes, banned_users
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                users = data.get("users", {})
                configs = data.get("configs", {})
                purchase_logs = [
                    {k: datetime.fromisoformat(v) if k == "timestamp" else v for k, v in log.items()}
                    for log in data.get("purchase_logs", [])
                ]
                access_logs = data.get("access_logs", [])
                gift_codes = data.get("gift_codes", {})
                banned_users = set(data.get("banned_users", []))
            users = {int(k): v for k, v in users.items()}
            configs = {k: v for k, v in configs.items()}
            gift_codes = {k: v for k, v in gift_codes.items()}
        except Exception as e:
            logger.error(f"Failed to load users data: {e}")
            send_log(None, f"Erro ao carregar dados: {e}")

def is_owner(user_id):
    return user_id == OWNER_ID

def check_rate_limit(user_id):
    """Check rate limit and detect abuse."""
    if user_id in user_locks:
        last_action = user_locks[user_id]
        if datetime.now() - last_action < timedelta(seconds=2):
            return False, "Por favor, aguarde alguns segundos antes de tentar novamente."
    
    now = datetime.now()
    request_counts[user_id] = [t for t in request_counts[user_id] if now - t < timedelta(minutes=1)]
    request_counts[user_id].append(now)
    
    if len(request_counts[user_id]) > 50:
        banned_users.add(user_id)
        save_users_data()
        send_log(None, f"Usuário {user_id} banido por abuso (muitas requisições).")
        return False, "Você foi banido por abuso. Contate o suporte."
    
    if len(request_counts[user_id]) > 10:
        return False, "Limite de requisições excedido. Tente novamente em um minuto."
    
    user_locks[user_id] = now
    return True, None

def check_group_membership(context: CallbackContext, user_id: int) -> bool:
    """Check if user is in the required group with caching."""
    now = datetime.now()
    cache_key = (user_id, GROUP_REQUIRED_ID)
    cache_duration = timedelta(seconds=10)

    if cache_key in group_membership_cache:
        cached_time, is_member = group_membership_cache[cache_key]
        if now - cached_time < cache_duration:
            logger.info(f"Cache hit for user {user_id}: is_member={is_member}")
            return is_member

    try:
        member = context.bot.get_chat_member(GROUP_REQUIRED_ID, user_id)
        is_member = member.status in ['member', 'administrator', 'creator']
        group_membership_cache[cache_key] = (now, is_member)
        logger.info(f"Checked group membership for user {user_id}: is_member={is_member}")
        return is_member
    except Exception as e:
        logger.error(f"Failed to check group membership for user {user_id}: {e}")
        group_membership_cache[cache_key] = (now, False)
        send_log(context, f"Erro ao verificar grupo para usuário {user_id}: {e}")
        return False

def send_log(context: CallbackContext, message: str):
    """Send log to group and save to file."""
    try:
        if context and hasattr(context, 'bot'):
            context.bot.send_message(
                chat_id=GROUP_LOG_ID,
                text=f"📋 LOG: {message}"
            )
    except Exception as e:
        logger.error(f"Failed to send log: {e}")
    with open("bot_logs.txt", "a", encoding="utf-8") as f:
        f.write(f"{datetime.now()}: {message}\n")

def require_group_membership(update, context: CallbackContext) -> bool:
    """Check if user is in the required group and handle if not."""
    user_id = getattr(update, 'effective_user', getattr(update, 'from_user', None)).id
    if user_id in banned_users:
        update.message.reply_text("❌ Você está banido. Contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a> para suporte.", parse_mode="HTML")
        return False
    if bot_locked and not is_owner(user_id):
        update.message.reply_text("🔒 O bot está em manutenção. Tente novamente mais tarde.", parse_mode="HTML")
        return False
    if not check_group_membership(context, user_id):
        update.message.reply_text(
            "🚫 Você precisa entrar no grupo oficial para usar o bot!\nClique abaixo para entrar:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Entrar no Grupo", url="https://t.me/ConfigBrasil")],
            ]),
            parse_mode="HTML"
        )
        return False
    return True

def start(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return

    user = update.effective_user
    user_id = user.id
    username = user.username or "N/A"
    name = user.full_name or "N/A"

    allowed, message = check_rate_limit(user_id)
    if not allowed:
        update.message.reply_text(f"❌ {message}", parse_mode="HTML")
        return

    access_logs.append(f"User {user_id} ({username}) accessed /start")
    send_log(context, f"Usuário {user_id} ({username}) usou /start")

    if user_id not in users:
        users[user_id] = {
            "username": username,
            "name": name,
            "balance": 0.0,
            "purchases": [],
            "gifts": 0,
        }

    welcome_text = sanitize_html(
        f"👋 <b>Bem-vindo, {name}!</b> ✨\n"
        "Você está no melhor bot de configs para OpenBullet/SilverBullet! 🚀\n\n"
        "<b>📋 SEU PERFIL</b>\n"
        f"👤 Nome: {name}\n"
        f"📛 Username: @{username.lstrip('@')}\n"
        f"🆔 ID: {user_id}\n"
        f"💰 Saldo: R${users[user_id]['balance']:.2f}\n\n"
        "⚠️ Qualquer dúvida, chame o suporte! 📞"
    )

    keyboard = [
        [
            InlineKeyboardButton("🔧 Configs", callback_data="configs_1"),
            InlineKeyboardButton("💵 Adicionar Saldo", callback_data="add_balance"),
        ],
        [
            InlineKeyboardButton("💳 Carteira", callback_data="wallet"),
            InlineKeyboardButton("📞 Suporte", callback_data="support"),
        ],
    ]
    if is_owner(user_id):
        keyboard.append([InlineKeyboardButton("📋 Painel Admin", callback_data="admin_panel")])
    reply_markup = InlineKeyboardMarkup(keyboard)

    context.user_data["previous_menu"] = None

    photo_path = "photo.jpg"
    video_path = "video.mp4"
    if os.path.exists(video_path):
        try:
            update.message.reply_video(
                video=open(video_path, 'rb'),
                caption=welcome_text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Failed to send video: {e}")
            update.message.reply_text(
                welcome_text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
    elif os.path.exists(photo_path):
        try:
            update.message.reply_photo(
                photo=open(photo_path, 'rb'),
                caption=welcome_text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
        except Exception as e:
            logger.error(f"Failed to send photo: {e}")
            update.message.reply_text(
                welcome_text,
                reply_markup=reply_markup,
                parse_mode="HTML"
            )
    else:
        update.message.reply_text(
            welcome_text,
            reply_markup=reply_markup,
            parse_mode="HTML"
        )
    save_users_data()

def handle_new_member(update: Update, context: CallbackContext):
    for member in update.message.new_chat_members:
        user_id = member.id
        username = member.username or "N/A"
        name = member.full_name or "N/A"

        allowed, message = check_rate_limit(user_id)
        if not allowed:
            update.message.reply_text(f"❌ {message}", parse_mode="HTML")
            return

        access_logs.append(f"New member {user_id} ({username}) joined the group")
        send_log(context, f"Novo membro {user_id} ({username}) entrou no grupo")

        if user_id not in users:
            users[user_id] = {
                "username": username,
                "name": name,
                "balance": 0.0,
                "purchases": [],
                "gifts": 0,
            }
        save_users_data()

def button_handler(update: Update, context: CallbackContext):
    query = update.callback_query
    query.answer()
    user_id = query.from_user.id

    if not require_group_membership(query, context):
        return

    allowed, message = check_rate_limit(user_id)
    if not allowed:
        query.message.reply_text(f"❌ {message}", parse_mode="HTML")
        return

    try:
        context.bot.delete_message(chat_id=query.message.chat_id, message_id=query.message.message_id)
    except:
        pass

    try:
        if query.data.startswith("configs_"):
            page = int(query.data.split("_")[1])
            configs_per_page = 5
            config_list = list(configs.items())
            total_pages = max(1, (len(config_list) + configs_per_page - 1) // configs_per_page)
            page = max(1, min(page, total_pages))
            start_idx = (page - 1) * configs_per_page
            end_idx = start_idx + configs_per_page
            current_configs = config_list[start_idx:end_idx]

            text = sanitize_html(
                "<b>🔧 CONFIGS DISPONÍVEIS</b> ✨\n\n"
                + ("Nenhuma configuração disponível no momento. 😔" if not configs else "")
            )
            for key, config in current_configs:
                text += f"🔹 {config['name']} - R${config['price']:.2f}\n"
            keyboard = [
                [InlineKeyboardButton(f"🔹 {config['name']} - R${config['price']:.2f}", callback_data=f"view_{key}")]
                for key, config in current_configs
            ]
            nav_buttons = []
            if page > 1:
                nav_buttons.append(InlineKeyboardButton("⬅️ Página Anterior", callback_data=f"configs_{page-1}"))
            if page < total_pages:
                nav_buttons.append(InlineKeyboardButton("Próxima Página ➡️", callback_data=f"configs_{page+1}"))
            if nav_buttons:
                keyboard.append(nav_buttons)
            keyboard.append([InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")])
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "start"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data.startswith("view_"):
            config_key = query.data[5:]
            config = configs.get(config_key)
            if not config:
                query.message.reply_text("❌ Configuração não encontrada!", parse_mode="HTML")
                return
            desc = config.get("description", {})
            text = sanitize_html(
                f"<b>🔧 {config['name']}</b> ✨\n"
                f"💰 Preço: R${config['price']:.2f}\n\n"
                f"<b>📋 Detalhes</b>\n"
                f"🌐 Site/App: {desc.get('site', 'N/A')}\n"
                f"⚡ CPM: {desc.get('cpm', 'N/A')}\n"
                f"🌍 Proxy: {desc.get('proxy', 'N/A')}\n"
                f"🔒 Precisa de Proxy: {desc.get('needs_proxy', 'N/A')}\n"
            )
            keyboard = [
                [InlineKeyboardButton("🛒 Comprar", callback_data=f"buy_{config_key}")],
                [InlineKeyboardButton("⬅️ Voltar", callback_data="configs_1")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "configs_1"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data.startswith("buy_"):
            config_key = query.data[4:]
            config = configs.get(config_key)
            if not config:
                query.message.reply_text("❌ Configuração não encontrada!", parse_mode="HTML")
                return
            user = users.get(user_id)
            if user["balance"] >= config["price"]:
                user["balance"] -= config["price"]
                user["purchases"].append(config["name"])
                purchase_logs.append({
                    "user_id": user_id,
                    "config_name": config["name"],
                    "price": config["price"],
                    "timestamp": datetime.now()
                })
                save_users_data()
                send_log(context, f"Usuário {user_id} comprou {config['name']} por R${config['price']:.2f}")
                try:
                    user_photos = context.bot.get_user_profile_photos(user_id, limit=1)
                    has_photo = user_photos.total_count > 0
                    caption = sanitize_html(f"✅ Compra realizada! Aqui está sua configuração: {config['name']} 🎉")
                    if has_photo:
                        photo_file = context.bot.get_file(user_photos.photos[0][0].file_id)
                        photo_path = f"temp_user_photo_{user_id}.jpg"
                        photo_file.download(photo_path)
                        query.message.reply_photo(
                            photo=open(photo_path, 'rb'),
                            caption=caption,
                            parse_mode="HTML"
                        )
                        query.message.reply_document(
                            document=open(os.path.join(CONFIG_DIR, config["filename"]), 'rb'),
                            filename=config["original_filename"],
                            parse_mode="HTML"
                        )
                        os.remove(photo_path)
                    else:
                        query.message.reply_document(
                            document=open(os.path.join(CONFIG_DIR, config["filename"]), 'rb'),
                            filename=config["original_filename"],
                            caption=caption,
                            parse_mode="HTML"
                        )
                except FileNotFoundError:
                    query.message.reply_text("❌ Erro: Arquivo de configuração não encontrado. Contate o suporte! 📞", parse_mode="HTML")
            else:
                keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="configs_1")]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = "configs_1"
                query.message.reply_text(
                    sanitize_html("❌ Saldo insuficiente! Adicione saldo para comprar esta configuração. 💵"),
                    reply_markup=reply_markup,
                    parse_mode="HTML"
                )

        elif query.data == "support":
            keyboard = [
                [InlineKeyboardButton("📞 Abrir Suporte", url="https://t.me/Coelho_ofc")],
                [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "start"
            query.message.reply_text(
                sanitize_html("<b>📞 SUPORTE</b> ✨\nClique abaixo para entrar em contato:"),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "wallet":
            user = users.get(user_id)
            total_spent = sum(
                configs.get(next((k for k, v in configs.items() if v["name"] == p), None), {"price": 0}).get("price", 0)
                for p in user["purchases"]
            )
            text = sanitize_html(
                f"<b>💳 SUA CARTEIRA</b> ✨\n\n"
                f"🆔 ID: {user_id}\n"
                f"💰 Saldo: R${user['balance']:.2f}\n\n"
                f"<b>🛒 COMPRAS</b>\n"
                f"📦 Configs Compradas: {len(user['purchases'])}\n"
                f"📋 Nomes: {', '.join(user['purchases']) or 'Nenhuma'}\n"
                f"🎁 Gifts Resgatados: {user['gifts']}\n"
                f"💸 Total Gasto: R${total_spent:.2f}"
            )
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "start"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "add_balance":
            text = sanitize_html("<b>💵 ADICIONAR SALDO</b> ✨\nSelecione a opção desejada:")
            keyboard = [
                [InlineKeyboardButton("💸 PIX Manual", callback_data="pix_manual")],
                [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "start"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "pix_manual":
            text = sanitize_html(
                "<b>💸 PIX Manual</b> ✨\n"
                "Selecione um valor para gerar o QR Code PIX ou escolha 'Outro Valor' e use /pix [valor]."
            )
            keyboard = [
                [
                    InlineKeyboardButton("R$50", callback_data="pix_value_50"),
                    InlineKeyboardButton("R$100", callback_data="pix_value_100"),
                    InlineKeyboardButton("R$200", callback_data="pix_value_200"),
                ],
                [InlineKeyboardButton("Outro Valor", callback_data="pix_other")],
                [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_add_balance")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "add_balance"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "pix_other":
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_add_balance")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "add_balance"
            query.message.reply_text(
                sanitize_html(
                    "<b>💸 Outro Valor</b> ✨\n"
                    "Digite <code>/pix [valor]</code> com um valor mínimo de R$9,99 (ex.: /pix 15.50)."
                ),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data.startswith("pix_value_"):
            amount = float(query.data.split("_")[2])
            try:
                username = query.from_user.username or query.from_user.first_name or str(user_id)
                payload = {
                    "key_type": "Outro",
                    "key": "9d53eed5-a57f-4f06-a42e-633b2bc99379",
                    "name": "Ismael Goncalves cerqueira",
                    "city": "",
                    "amount": f"R${amount:.2f}",
                    "reference": username
                }
                headers = {
                    "Content-Type": "application/json",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
                    "Pragma": "no-cache",
                    "Accept": "*/*"
                }
                response = requests.post("https://www.gerarpix.com.br/emvqr-static", json=payload, headers=headers)
                if response.status_code == 200:
                    response_data = response.json()
                    pix_code = response_data.get("code")
                    if pix_code:
                        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
                        qr.add_data(pix_code)
                        qr.make(fit=True)
                        img = qr.make_image(fill_color="black", back_color="white")
                        qr_filename = f"pix_qrcode_{user_id}.png"
                        img.save(qr_filename)
                        caption = sanitize_html(
                            f"Escaneie o QR Code para pagamento PIX.\n\n"
                            f"Também pode copiar o código abaixo e colar no aplicativo do seu banco.\n\n"
                            f"<b>Valor:</b> R${amount:.2f}\n"
                            f"<code>{pix_code}</code>\n\n"
                            f"<b>⚠️ Após o pagamento, envie o comprovante para @Coelho_ofc.</b>"
                        )
                        with open(qr_filename, "rb") as photo:
                            query.message.reply_photo(
                                photo=photo,
                                caption=caption,
                                parse_mode="HTML"
                            )
                        os.remove(qr_filename)
                    else:
                        query.message.reply_text("❌ Erro: Nenhum código PIX retornado pela API.", parse_mode="HTML")
                else:
                    query.message.reply_text(f"❌ Erro na API: {response.status_code} - {response.text}", parse_mode="HTML")
            except Exception as e:
                logger.error(f"Erro ao gerar QR Code: {e}")
                query.message.reply_text(f"❌ Erro ao gerar QR Code: {str(e)}", parse_mode="HTML")

        elif query.data == "admin_panel" and is_owner(user_id):
            text = sanitize_html("<b>📋 PAINEL DE ADMINISTRAÇÃO</b> ✨")
            keyboard = [
                [
                    InlineKeyboardButton("💰 Adicionar Saldo", callback_data="admin_add_balance"),
                    InlineKeyboardButton("💸 Remover Saldo", callback_data="admin_remove_balance"),
                ],
                [
                    InlineKeyboardButton("🎁 Criar Gift", callback_data="admin_create_gift"),
                    InlineKeyboardButton("🔧 Gerenciar Configs", callback_data="admin_manage_configs"),
                ],
                [
                    InlineKeyboardButton("📊 Relatórios", callback_data="admin_reports"),
                    InlineKeyboardButton("📁 Enviar Arquivo", callback_data="admin_send_file"),
                ],
                [
                    InlineKeyboardButton("🚫 Banir Usuário", callback_data="admin_ban"),
                    InlineKeyboardButton("✅ Desbanir Usuário", callback_data="admin_unban"),
                ],
                [
                    InlineKeyboardButton("📈 Estatísticas", callback_data="admin_stats"),
                    InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
                ],
                [
                    InlineKeyboardButton("🔒 Travar Bot", callback_data="admin_lock"),
                    InlineKeyboardButton("🔓 Destravar Bot", callback_data="admin_unlock"),
                ],
                [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "start"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "admin_add_balance" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>💰 Adicionar Saldo</b>\nDigite <code>/adicionarsaldo [user_id] [valor]</code> para adicionar saldo."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_remove_balance" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>💸 Remover Saldo</b>\nDigite <code>/removersaldo [user_id] [valor]</code> para remover saldo."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_create_gift" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>🎁 Criar Gift</b>\nDigite <code>/gift [valor]</code> para criar um gift card."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_manage_configs" and is_owner(user_id):
            text = sanitize_html("<b>🔧 GERENCIAR CONFIGS</b> ✨")
            keyboard = [
                [
                    InlineKeyboardButton("➕ Adicionar Config", callback_data="admin_add_config"),
                    InlineKeyboardButton("➖ Remover Config", callback_data="admin_remove_config"),
                ],
                [
                    InlineKeyboardButton("✏️ Modificar Config", callback_data="admin_modify_config"),
                    InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel"),
                ],
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "admin_add_config" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_manage_configs")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_manage_configs"
            query.message.reply_text(
                sanitize_html("<b>➕ Adicionar Config</b>\nDigite <code>/adicionarconfig [nome]|[preço]|[site]|[cpm]|[proxy]|[precisa_proxy]</code> e envie o arquivo."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_remove_config" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_manage_configs")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_manage_configs"
            query.message.reply_text(
                sanitize_html("<b>➖ Remover Config</b>\nDigite <code>/removerconfig</code> para ver as configs disponíveis."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_modify_config" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_manage_configs")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_manage_configs"
            query.message.reply_text(
                sanitize_html("<b>✏️ Modificar Config</b>\nDigite <code>/modificarconfig [nome_antigo] [novo_nome] [novo_preço] [site] [cpm] [proxy] [precisa_proxy]</code> e envie o novo arquivo."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_reports" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>📊 Relatórios</b>\nDigite <code>/relatorio [diario|semanal|atual]</code> para ver os relatórios de vendas."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_send_file" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>📁 Enviar Arquivo</b>\nDigite <code>/enviararquivo [user_id] [nome_arquivo]</code> para enviar um arquivo a um usuário."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_ban" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>🚫 Banir Usuário</b>\nDigite <code>/ban [user_id]</code> para banir um usuário."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_unban" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>✅ Desbanir Usuário</b>\nDigite <code>/unban [user_id]</code> para desbanir um usuário."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_stats" and is_owner(user_id):
            total_users = len(users)
            total_configs = len(configs)
            total_sales = sum(log["price"] for log in purchase_logs)
            total_purchases = len(purchase_logs)
            text = sanitize_html(
                f"<b>📈 ESTATÍSTICAS DO BOT</b> ✨\n\n"
                f"👥 Usuários: {total_users}\n"
                f"🔧 Configs: {total_configs}\n"
                f"🛒 Vendas Totais: {total_purchases}\n"
                f"💰 Receita Total: R${total_sales:.2f}"
            )
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

        elif query.data == "admin_broadcast" and is_owner(user_id):
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(
                sanitize_html("<b>📢 Broadcast</b>\nDigite <code>/broadcast [mensagem]</code> para enviar uma mensagem a todos os usuários."),
                reply_markup=reply_markup,
                parse_mode="HTML"
            )

        elif query.data == "admin_lock" and is_owner(user_id):
            global bot_locked
            bot_locked = True
            save_users_data()
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(sanitize_html("<b>🔒 Bot travado para manutenção.</b>"), reply_markup=reply_markup, parse_mode="HTML")
            send_log(context, "Bot travado para manutenção pelo admin.")

        elif query.data == "admin_unlock" and is_owner(user_id):
            
            bot_locked = False
            save_users_data()
            keyboard = [[InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel")]]
            reply_markup = InlineKeyboardMarkup(keyboard)
            context.user_data["previous_menu"] = "admin_panel"
            query.message.reply_text(sanitize_html("<b>🔓 Bot destravado.</b>"), reply_markup=reply_markup, parse_mode="HTML")
            send_log(context, "Bot destravado pelo admin.")

        elif query.data.startswith("remove_config_"):
            config_id = query.data[len("remove_config_"):]
            config = configs.get(config_id)
            if not config:
                query.message.reply_text("❌ Config não encontrada!", parse_mode="HTML")
                return
            if config["filename"]:
                try:
                    os.remove(os.path.join(CONFIG_DIR, config["filename"]))
                except:
                    pass
            config_name = config["name"]
            del configs[config_id]
            save_users_data()
            query.message.reply_text(
                sanitize_html(f"✅ Config {config_name} removida. ➖"),
                parse_mode="HTML"
            )
            send_log(context, f"Admin removeu config {config_name}")

        elif query.data.startswith("back_to_"):
            previous_menu = query.data[8:]
            if previous_menu == "start":
                user = users.get(user_id, {"name": query.from_user.full_name or "N/A", "username": query.from_user.username or "N/A", "balance": 0.0, "purchases": [], "gifts": 0})
                welcome_text = sanitize_html(
                    f"👋 <b>Bem-vindo, {user['name']}!</b> ✨\n"
                    "Você está no melhor bot de configs para OpenBullet/SilverBullet! 🚀\n\n"
                    "<b>📋 SEU PERFIL</b>\n"
                    f"👤 Nome: {user['name']}\n"
                    f"📛 Username: @{user['username'].lstrip('@')}\n"
                    f"🆔 ID: {user_id}\n"
                    f"💰 Saldo: R${user['balance']:.2f}\n\n"
                    "⚠️ Qualquer dúvida, chame o suporte! 📞"
                )
                keyboard = [
                    [
                        InlineKeyboardButton("🔧 Adquirir Configs", callback_data="configs_1"),
                        InlineKeyboardButton("💵 Adicionar Saldo", callback_data="add_balance"),
                    ],
                    [
                        InlineKeyboardButton("💳 Carteira", callback_data="wallet"),
                        InlineKeyboardButton("📞 Suporte", callback_data="support"),
                    ],
                ]
                if is_owner(user_id):
                    keyboard.append([InlineKeyboardButton("📋 Painel Admin", callback_data="admin_panel")])
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = None
                photo_path = "photo.jpg"
                video_path = "video.mp4"
                if os.path.exists(video_path):
                    try:
                        query.message.reply_video(
                            video=open(video_path, 'rb'),
                            caption=welcome_text,
                            reply_markup=reply_markup,
                            parse_mode="HTML"
                        )
                    except Exception as e:
                        logger.error(f"Failed to send video: {e}")
                        query.message.reply_text(
                            welcome_text,
                            reply_markup=reply_markup,
                            parse_mode="HTML"
                        )
                elif os.path.exists(photo_path):
                    try:
                        query.message.reply_photo(
                            photo=open(photo_path, 'rb'),
                            caption=welcome_text,
                            reply_markup=reply_markup,
                            parse_mode="HTML"
                        )
                    except Exception as e:
                        logger.error(f"Failed to send photo: {e}")
                        query.message.reply_text(
                            welcome_text,
                            reply_markup=reply_markup,
                            parse_mode="HTML"
                        )
                else:
                    query.message.reply_text(
                        welcome_text,
                        reply_markup=reply_markup,
                        parse_mode="HTML"
                    )

            elif previous_menu.startswith("configs_"):
                page = int(previous_menu.split("_")[1]) if "_" in previous_menu else 1
                configs_per_page = 5
                config_list = list(configs.items())
                total_pages = max(1, (len(config_list) + configs_per_page - 1) // configs_per_page)
                page = max(1, min(page, total_pages))
                start_idx = (page - 1) * configs_per_page
                end_idx = start_idx + configs_per_page
                current_configs = config_list[start_idx:end_idx]

                text = sanitize_html(
                    "<b>🔧 CONFIGS DISPONÍVEIS</b> ✨\n\n"
                    + ("Nenhuma configuração disponível no momento. 😔" if not configs else "")
                )
                for key, config in current_configs:
                    text += f"🔹 {config['name']} - R${config['price']:.2f}\n"
                keyboard = [
                    [InlineKeyboardButton(f"🔹 {config['name']} - R${config['price']:.2f}", callback_data=f"view_{key}")]
                    for key, config in current_configs
                ]
                nav_buttons = []
                if page > 1:
                    nav_buttons.append(InlineKeyboardButton("⬅️ Página Anterior", callback_data=f"configs_{page-1}"))
                if page < total_pages:
                    nav_buttons.append(InlineKeyboardButton("Próxima Página ➡️", callback_data=f"configs_{page+1}"))
                if nav_buttons:
                    keyboard.append(nav_buttons)
                keyboard.append([InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")])
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = "start"
                query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

            elif previous_menu == "add_balance":
                text = sanitize_html("<b>💵 ADICIONAR SALDO</b> ✨\nSelecione a opção desejada:")
                keyboard = [
                    [InlineKeyboardButton("💸 PIX Manual", callback_data="pix_manual")],
                    [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")],
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = "start"
                query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

            elif previous_menu == "admin_panel" and is_owner(user_id):
                text = sanitize_html("<b>📋 PAINEL DE ADMINISTRAÇÃO</b> ✨")
                keyboard = [
                    [
                        InlineKeyboardButton("💰 Adicionar Saldo", callback_data="admin_add_balance"),
                        InlineKeyboardButton("💸 Remover Saldo", callback_data="admin_remove_balance"),
                    ],
                    [
                        InlineKeyboardButton("🎁 Criar Gift", callback_data="admin_create_gift"),
                        InlineKeyboardButton("🔧 Gerenciar Configs", callback_data="admin_manage_configs"),
                    ],
                    [
                        InlineKeyboardButton("📊 Relatórios", callback_data="admin_reports"),
                        InlineKeyboardButton("📁 Enviar Arquivo", callback_data="admin_send_file"),
                    ],
                    [
                        InlineKeyboardButton("🚫 Banir Usuário", callback_data="admin_ban"),
                        InlineKeyboardButton("✅ Desbanir Usuário", callback_data="admin_unban"),
                    ],
                    [
                        InlineKeyboardButton("📈 Estatísticas", callback_data="admin_stats"),
                        InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
                    ],
                    [
                        InlineKeyboardButton("🔒 Travar Bot", callback_data="admin_lock"),
                        InlineKeyboardButton("🔓 Destravar Bot", callback_data="admin_unlock"),
                    ],
                    [InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_start")],
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = "start"
                query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

            elif previous_menu == "admin_manage_configs" and is_owner(user_id):
                text = sanitize_html("<b>🔧 GERENCIAR CONFIGS</b> ✨")
                keyboard = [
                    [
                        InlineKeyboardButton("➕ Adicionar Config", callback_data="admin_add_config"),
                        InlineKeyboardButton("➖ Remover Config", callback_data="admin_remove_config"),
                    ],
                    [
                        InlineKeyboardButton("✏️ Modificar Config", callback_data="admin_modify_config"),
                        InlineKeyboardButton("⬅️ Voltar", callback_data="back_to_admin_panel"),
                    ],
                ]
                reply_markup = InlineKeyboardMarkup(keyboard)
                context.user_data["previous_menu"] = "admin_panel"
                query.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")

    except Exception as e:
        query.message.reply_text(
            sanitize_html("❌ Ocorreu um erro. Tente novamente ou contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>. 📞"),
            parse_mode="HTML"
        )
        logger.error(f"Error in button_handler: {e}")
        send_log(context, f"Erro em button_handler: {e}")

def adicionar_saldo(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        user_id = int(context.args[0])
        amount = float(context.args[1])
        if amount <= 0:
            update.message.reply_text("❌ O valor deve ser maior que zero!", parse_mode="HTML")
            return
        if user_id not in users:
            update.message.reply_text("❌ Usuário não encontrado!", parse_mode="HTML")
            return
        users[user_id]["balance"] += amount
        save_users_data()
        update.message.reply_text(
            sanitize_html(f"✅ Saldo de R${amount:.2f} adicionado ao usuário {user_id}. 💰"),
            parse_mode="HTML"
        )
        send_log(context, f"Admin adicionou R${amount:.2f} ao usuário {user_id}")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/adicionarsaldo [user_id] [valor]</code>"),
            parse_mode="HTML"
        )

def remover_saldo(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        user_id = int(context.args[0])
        amount = float(context.args[1])
        if amount <= 0:
            update.message.reply_text("❌ O valor deve ser maior que zero!", parse_mode="HTML")
            return
        if user_id not in users:
            update.message.reply_text("❌ Usuário não encontrado!", parse_mode="HTML")
            return
        if users[user_id]["balance"] < amount:
            update.message.reply_text("❌ Saldo insuficiente para remover!", parse_mode="HTML")
            return
        users[user_id]["balance"] -= amount
        save_users_data()
        update.message.reply_text(
            sanitize_html(f"✅ Saldo de R${amount:.2f} removido do usuário {user_id}. 💸"),
            parse_mode="HTML"
        )
        send_log(context, f"Admin removeu R${amount:.2f} do usuário {user_id}")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/removersaldo [user_id] [valor]</code>"),
            parse_mode="HTML"
        )

def gift(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        amount = float(context.args[0])
        if amount <= 0:
            update.message.reply_text("❌ O valor do gift deve ser maior que zero!", parse_mode="HTML")
            return
        code = str(uuid.uuid4())[:8]
        gift_codes[code] = {"value": amount, "used": False, "user_id": None}
        save_users_data()
        update.message.reply_text(
            sanitize_html(f"🎁 Gift card criado! Código: {code}, Valor: R${amount:.2f}."),
            parse_mode="HTML"
        )
        send_log(context, f"Admin criou gift card {code} com valor R${amount:.2f}")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/gift [valor]</code>"),
            parse_mode="HTML"
        )

def resgatar(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    user_id = update.effective_user.id
    try:
        code = context.args[0].strip()
        if code not in gift_codes:
            update.message.reply_text("❌ Código de gift inválido!", parse_mode="HTML")
            return
        if gift_codes[code]["used"]:
            update.message.reply_text("❌ Este gift já foi resgatado!", parse_mode="HTML")
            return
        gift_codes[code]["used"] = True
        gift_codes[code]["user_id"] = user_id
        users[user_id]["balance"] += gift_codes[code]["value"]
        users[user_id]["gifts"] += 1
        save_users_data()
        update.message.reply_text(
            sanitize_html(f"🎁 Gift resgatado! R${gift_codes[code]['value']:.2f} adicionado ao seu saldo. 💰"),
            parse_mode="HTML"
        )
        send_log(context, f"Usuário {user_id} resgatou gift card {code} por R${gift_codes[code]['value']:.2f}")
    except IndexError:
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/resgatar [código]</code>"),
            parse_mode="HTML"
        )

def adicionar_config(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        args = context.args
        if len(args) != 1:
            raise ValueError("Formato inválido: use um único argumento com separador '|'")
        
        config_data = args[0].split('|')
        if len(config_data) < 2 or len(config_data) > 6:
            raise ValueError("Número inválido de argumentos. Use: nome|preço|[site]|[cpm]|[proxy]|[precisa_proxy]")

        name = config_data[0].strip()
        price = float(config_data[1].strip())
        site = config_data[2].strip() if len(config_data) > 2 else "N/A"
        cpm = config_data[3].strip() if len(config_data) > 3 else "N/A"
        proxy = config_data[4].strip() if len(config_data) > 4 else "N/A"
        needs_proxy = config_data[5].strip().lower() in ['sim', 'yes', 'true', '✅'] if len(config_data) > 5 else False

        if price <= 0:
            update.message.reply_text("❌ O preço deve ser maior que zero!", parse_mode="HTML")
            return

        config_id = str(uuid.uuid4())
        configs[config_id] = {
            "name": name,
            "price": price,
            "filename": None,
            "original_filename": None,
            "description": {
                "site": site,
                "cpm": cpm,
                "proxy": proxy,
                "needs_proxy": needs_proxy
            }
        }
        context.user_data["pending_config"] = config_id
        save_users_data()
        update.message.reply_text("➕ Envie o arquivo da configuração agora.", parse_mode="HTML")
        logger.info(f"Configuração criada: {name}, ID: {config_id}")
        send_log(context, f"Admin criou config {name} com preço R${price:.2f}")
    except (ValueError, IndexError) as e:
        logger.error(f"Erro ao adicionar config: {e}, args: {args}")
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/adicionarconfig [nome]|[preço]|[site]|[cpm]|[proxy]|[precisa_proxy]</code>\n"
                         "Exemplo: <code>/adicionarconfig FlyTap|250|https://www.flytap.com/pt-br|350|SIM|sim</code>"),
            parse_mode="HTML"
        )

def remover_config(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    if not configs:
        update.message.reply_text("❌ Nenhuma config disponível para remover!", parse_mode="HTML")
        return

    keyboard = [
        [InlineKeyboardButton(f"🔹 {config['name']} - R${config['price']:.2f}", callback_data=f"remove_config_{key}")]
        for key, config in configs.items()
    ]
    keyboard.append([InlineKeyboardButton("⬅️ Cancelar", callback_data="back_to_admin_manage_configs")])
    reply_markup = InlineKeyboardMarkup(keyboard)

    update.message.reply_text(
        sanitize_html("<b>➖ Selecione a Config para Remover</b> ✨"),
        reply_markup=reply_markup,
        parse_mode="HTML"
    )

def modificar_config(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        args = context.args
        if len(args) < 6:
            raise ValueError("Argumentos insuficientes")
        new_price = float(args[-4])
        description = {
            "site": args[-3],
            "cpm": args[-2],
            "proxy": args[-1],
            "needs_proxy": args[-1].lower() in ['sim', 'yes', 'true']
        }
        new_name = args[-5]
        old_name = ' '.join(args[:-5])
        if new_price <= 0:
            update.message.reply_text("❌ O preço deve ser maior que zero!", parse_mode="HTML")
            return
        config_id = next((k for k, v in configs.items() if v["name"] == old_name), None)
        if not config_id:
            update.message.reply_text("❌ Config não encontrada!", parse_mode="HTML")
            return
        configs[config_id]["name"] = new_name
        configs[config_id]["price"] = new_price
        configs[config_id]["description"] = description
        context.user_data["pending_config"] = config_id
        save_users_data()
        update.message.reply_text("✏️ Envie o novo arquivo da configuração agora.", parse_mode="HTML")
    except (ValueError, IndexError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/modificarconfig [nome_antigo] [novo_nome] [novo_preço] [site] [cpm] [proxy] [precisa_proxy]</code>"),
            parse_mode="HTML"
        )

def enviar_arquivo(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        user_id = int(context.args[0])
        filename = ' '.join(context.args[1:])
        filepath = os.path.join(CONFIG_DIR, filename)
        if not os.path.exists(filepath):
            update.message.reply_text("❌ Arquivo não encontrado!", parse_mode="HTML")
            return
        context.bot.send_document(
            chat_id=user_id,
            document=open(filepath, 'rb'),
            caption=sanitize_html(f"📁 Arquivo enviado pelo admin: {filename}"),
            parse_mode="HTML"
        )
        update.message.reply_text(
            sanitize_html(f"✅ Arquivo {filename} enviado ao usuário {user_id}. 📁"),
            parse_mode="HTML"
        )
        send_log(context, f"Admin enviou arquivo {filename} ao usuário {user_id}")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/enviararquivo [user_id] [nome_arquivo]</code>"),
            parse_mode="HTML"
        )

def relatorio_vendas(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        report_type = context.args[0].lower()
        now = datetime.now()
        if report_type == "diario":
            start_time = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end_time = start_time + timedelta(days=1)
        elif report_type == "semanal":
            start_time = now - timedelta(days=now.weekday())
            start_time = start_time.replace(hour=0, minute=0, second=0, microsecond=0)
            end_time = start_time + timedelta(days=7)
        elif report_type == "atual":
            start_time = datetime.min
            end_time = now
        else:
            update.message.reply_text(
                sanitize_html("❌ Uso: <code>/relatorio [diario|semanal|atual]</code>"),
                parse_mode="HTML"
            )
            return

        filtered_logs = [
            log for log in purchase_logs
            if start_time <= log["timestamp"] < end_time
        ]
        total_sales = sum(log["price"] for log in filtered_logs)
        total_count = len(filtered_logs)
        report_text = sanitize_html(
            f"<b>📊 RELATÓRIO DE VENDAS ({report_type.upper()})</b> ✨\n\n"
            f"🛒 Total de Vendas: {total_count}\n"
            f"💰 Valor Total: R${total_sales:.2f}\n\n"
            f"<b>📋 Detalhes</b>\n"
        )
        for log in filtered_logs:
            report_text += f"👤 Usuário {log['user_id']} comprou {log['config_name']} por R${log['price']:.2f} em {log['timestamp'].strftime('%d/%m/%Y %H:%M')}\n"
        if not filtered_logs:
            report_text += "Nenhuma venda no período. 😔"

        update.message.reply_text(report_text, parse_mode="HTML")
        send_log(context, f"Admin solicitou relatório {report_type}")
    except IndexError:
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/relatorio [diario|semanal|atual]</code>"),
            parse_mode="HTML"
        )

def perfil(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    user_id = update.effective_user.id
    user = users.get(user_id, {
        "name": update.effective_user.full_name or "N/A",
        "username": update.effective_user.username or "N/A",
        "balance": 0.0,
        "purchases": [],
        "gifts": 0
    })
    total_spent = sum(
        configs.get(next((k for k, v in configs.items() if v["name"] == p), None), {"price": 0}).get("price", 0)
        for p in user["purchases"]
    )
    text = sanitize_html(
        f"<b>👤 SEU PERFIL</b> ✨\n\n"
        f"📛 Nome: {user['name']}\n"
        f"📱 Username: @{user['username'].lstrip('@')}\n"
        f"🆔 ID: {user_id}\n"
        f"💰 Saldo: R${user['balance']:.2f}\n"
        f"🛒 Configs Compradas: {len(user['purchases'])}\n"
        f"🎁 Gifts Resgatados: {user['gifts']}\n"
        f"💸 Total Gasto: R${total_spent:.2f}"
    )
    update.message.reply_text(text, parse_mode="HTML")

def historico(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    user_id = update.effective_user.id
    user_purchases = [log for log in purchase_logs if log["user_id"] == user_id][-10:]
    text = sanitize_html("<b>🛒 SEU HISTÓRICO DE COMPRAS</b> ✨\n\n")
    if not user_purchases:
        text += "Nenhuma compra realizada. 😔"
    else:
        for log in user_purchases:
            text += f"📦 {log['config_name']} - R${log['price']:.2f} em {log['timestamp'].strftime('%d/%m/%Y %H:%M')}\n"
    update.message.reply_text(text, parse_mode="HTML")

def suporte(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    update.message.reply_text(
        sanitize_html("<b>📞 SUPORTE</b> ✨\nClique abaixo para entrar em contato:"),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📞 Abrir Suporte", url="https://t.me/Coelho_ofc")],
        ]),
        parse_mode="HTML"
    )

def ban(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        user_id = int(context.args[0])
        if user_id == OWNER_ID:
            update.message.reply_text("❌ Não é possível banir o dono!", parse_mode="HTML")
            return
        banned_users.add(user_id)
        save_users_data()
        update.message.reply_text(sanitize_html(f"✅ Usuário {user_id} banido. 🚫"), parse_mode="HTML")
        send_log(context, f"Admin baniu usuário {user_id}")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/ban [user_id]</code>"),
            parse_mode="HTML"
        )

def unban(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        user_id = int(context.args[0])
        if user_id in banned_users:
            banned_users.remove(user_id)
            save_users_data()
            update.message.reply_text(sanitize_html(f"✅ Usuário {user_id} desbanido. ✅"), parse_mode="HTML")
            send_log(context, f"Admin desbaniu usuário {user_id}")
        else:
            update.message.reply_text("❌ Usuário não está banido!", parse_mode="HTML")
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/unban [user_id]</code>"),
            parse_mode="HTML"
        )

def broadcast(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    if not is_owner(update.effective_user.id):
        update.message.reply_text("❌ Acesso negado! Apenas o dono pode usar este comando.", parse_mode="HTML")
        return

    try:
        message = ' '.join(context.args)
        if not message:
            update.message.reply_text(
                sanitize_html("❌ Uso: <code>/broadcast [mensagem]</code>"),
                parse_mode="HTML"
            )
            return
        for user_id in users:
            try:
                context.bot.send_message(
                    chat_id=user_id,
                    text=sanitize_html(f"<b>📢 AVISO DO BOT</b> ✨\n{message}"),
                    parse_mode="HTML"
                )
            except:
                continue
        update.message.reply_text(sanitize_html("✅ Mensagem enviada para todos os usuários. 📢"), parse_mode="HTML")
        send_log(context, f"Admin enviou broadcast: {message}")
    except IndexError:
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/broadcast [mensagem]</code>"),
            parse_mode="HTML"
        )

def pix(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return

    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name or str(user_id)

    try:
        amount = float(context.args[0])
        if amount < 9.99:
            update.message.reply_text(
                sanitize_html("❌ O valor mínimo é R$9,99. Tente novamente."),
                parse_mode="HTML"
            )
            return

        # Log do valor recebido
        logger.info(f"Gerando PIX para usuário {user_id}, valor: R${amount:.2f}")

        # Formatando o valor para a API com vírgula (ex.: "65,00")
        amount_str = f"{amount:.2f}".replace(".", ",")

        payload = {
            "key_type": "Outro",
            "key": "9d53eed5-a57f-4f06-a42e-633b2bc99379",
            "name": "Ismael Goncalves cerqueira",
            "city": "",
            "amount": amount_str,  # Ex.: "65,00"
            "reference": username
        }
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36",
            "Pragma": "no-cache",
            "Accept": "application/json"
        }
        response = requests.post(
            "https://www.gerarpix.com.br/emvqr-static",
            json=payload,
            headers=headers,
            timeout=10
        )

        # Logar status e resposta
        logger.info(f"Status da API: {response.status_code}")
        logger.info(f"Resposta bruta da API: {response.text[:1000]}")

        if response.status_code == 200 and "application/json" in response.headers.get("Content-Type", "").lower():
            try:
                response_data = response.json()
                pix_code = response_data.get("code")
                if pix_code:
                    qr = qrcode.QRCode(
                        version=1,
                        error_correction=qrcode.constants.ERROR_CORRECT_L,
                        box_size=10,
                        border=4
                    )
                    qr.add_data(pix_code)
                    qr.make(fit=True)
                    img = qr.make_image(fill_color="black", back_color="white")
                    qr_filename = f"pix_qrcode_{user_id}.png"
                    img.save(qr_filename)
                    caption = sanitize_html(
                        f"Escaneie o QR Code para pagamento PIX.\n\n"
                        f"Também pode copiar o código abaixo e colar no aplicativo do seu banco.\n\n"
                        f"<b>Valor:</b> R${amount:.2f}\n"
                        f"<code>{pix_code}</code>\n\n"
                        f"<b>⚠️ Após o pagamento, envie o comprovante para @Coelho_ofc.</b>"
                    )
                    with open(qr_filename, "rb") as photo:
                        update.message.reply_photo(
                            photo=photo,
                            caption=caption,
                            parse_mode="HTML"
                        )
                    os.remove(qr_filename)
                    logger.info(f"PIX gerado com sucesso para usuário {user_id}, valor: R${amount:.2f}, enviado como {amount_str}")
                else:
                    update.message.reply_text(
                        sanitize_html("❌ Erro: Nenhum código PIX retornado pela API."),
                        parse_mode="HTML"
                    )
                    logger.error("Nenhum código PIX retornado pela API")
            except ValueError as e:
                logger.error(f"Erro ao parsear JSON: {e}, resposta: {response.text[:1000]}")
                update.message.reply_text(
                    sanitize_html("❌ Erro: Resposta inválida da API de PIX. Contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>."),
                    parse_mode="HTML"
                )
        else:
            logger.error(f"Resposta inválida: status {response.status_code}, content-type: {response.headers.get('Content-Type')}")
            update.message.reply_text(
                sanitize_html(f"❌ Erro na API: {response.status_code}. Contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>."),
                parse_mode="HTML"
            )
    except (IndexError, ValueError):
        update.message.reply_text(
            sanitize_html("❌ Uso: <code>/pix [valor]</code>\nExemplo: <code>/pix 65.00</code>"),
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Erro ao gerar QR Code: {e}")
        update.message.reply_text(
            sanitize_html(f"❌ Erro ao gerar QR Code: {str(e)}. Contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>."),
            parse_mode="HTML"
        )

def handle_document(update: Update, context: CallbackContext):
    if not require_group_membership(update, context):
        return
    user_id = update.effective_user.id
    if not is_owner(user_id) or "pending_config" not in context.user_data:
        return

    document = update.message.document
    if not document:
        update.message.reply_text("❌ Por favor, envie um arquivo válido.", parse_mode="HTML")
        return

    if not os.path.splitext(document.file_name)[1].lower() in ALLOWED_EXTENSIONS:
        update.message.reply_text("❌ Extensão de arquivo não permitida. Use .loli, .svb, .txt ou .config.", parse_mode="HTML")
        return

    config_id = context.user_data["pending_config"]
    if config_id not in configs:
        update.message.reply_text("❌ Erro: Configuração não encontrada. Tente novamente.", parse_mode="HTML")
        return

    file = context.bot.get_file(document.file_id)
    filename = f"{config_id}_{document.file_name}"
    file.download(os.path.join(CONFIG_DIR, filename))
    configs[config_id]["filename"] = filename
    configs[config_id]["original_filename"] = document.file_name
    save_users_data()
    update.message.reply_text(
        sanitize_html(f"✅ Arquivo {document.file_name} salvo para a configuração {configs[config_id]['name']}. ➕"),
        parse_mode="HTML"
    )
    send_log(context, f"Admin enviou arquivo {document.file_name} para config {configs[config_id]['name']}")
    del context.user_data["pending_config"]

def error_handler(update: Update, context: CallbackContext):
    error_msg = str(context.error)
    logger.error(f"Update {update} caused error {error_msg}")
    send_log(context, f"Erro: {error_msg}")
    if isinstance(context.error, urllib3.exceptions.HTTPError):
        error_text = "❌ Problema de conexão com o Telegram. Tente novamente em alguns minutos. 📞"
    else:
        error_text = "❌ Ocorreu um erro. Tente novamente ou contate <a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>. 📞"
    if update and hasattr(update, 'effective_message') and update.effective_message:
        try:
            update.effective_message.reply_text(
                sanitize_html(error_text),
                parse_mode="HTML"
            )
        except:
            update.effective_message.reply_text(
                error_text.replace("<a href='https://t.me/Coelho_ofc'>@Coelho_ofc</a>", "@Coelho_ofc")
            )

def main():
    load_users_data()
    updater = Updater(
        "7802909262:AAENOxph6svHGa_RIIuUvi898sbfa53pAdA",
        use_context=True,
        request_kwargs={'read_timeout': 30, 'connect_timeout': 30}
    )
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(MessageHandler(Filters.status_update.new_chat_members, handle_new_member))
    dp.add_handler(CallbackQueryHandler(button_handler))
    dp.add_handler(CommandHandler("adicionarsaldo", adicionar_saldo))
    dp.add_handler(CommandHandler("removersaldo", remover_saldo))
    dp.add_handler(CommandHandler("gift", gift))
    dp.add_handler(CommandHandler("resgatar", resgatar))
    dp.add_handler(CommandHandler("adicionarconfig", adicionar_config))
    dp.add_handler(CommandHandler("removerconfig", remover_config))
    dp.add_handler(CommandHandler("modificarconfig", modificar_config))
    dp.add_handler(CommandHandler("enviararquivo", enviar_arquivo))
    dp.add_handler(CommandHandler("relatorio", relatorio_vendas))
    dp.add_handler(CommandHandler("perfil", perfil))
    dp.add_handler(CommandHandler("historico", historico))
    dp.add_handler(CommandHandler("suporte", suporte))
    dp.add_handler(CommandHandler("ban", ban))
    dp.add_handler(CommandHandler("unban", unban))
    dp.add_handler(CommandHandler("broadcast", broadcast))
    dp.add_handler(CommandHandler("pix", pix))
    dp.add_handler(MessageHandler(Filters.document, handle_document))
    dp.add_error_handler(error_handler)

    max_retries = 5
    retry_count = 0
    while retry_count < max_retries:
        try:
            updater.start_polling(timeout=30)
            updater.idle()
            break
        except urllib3.exceptions.HTTPError as e:
            retry_count += 1
            logger.error(f"Connection error (attempt {retry_count}/{max_retries}): {e}")
            send_log(None, f"Erro de conexão (tentativa {retry_count}/{max_retries}): {e}")
            if retry_count == max_retries:
                logger.error("Max retries reached. Exiting.")
                send_log(None, "Máximo de tentativas de reconexão atingido. Encerrando.")
                raise
            import time
            time.sleep(5)

if __name__ == "__main__":
    main()
